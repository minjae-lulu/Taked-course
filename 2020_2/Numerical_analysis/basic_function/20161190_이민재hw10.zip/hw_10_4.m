function hw_10_4

xStart = 0.0; xStop = 1.0; dx = 0.1; dy = 0.1; yStart = 0.0; yStop = 1.0; 

J = (xStop-xStart)/dx+1;
x = linspace(xStart,xStop,J)';
y = linspace(yStart,yStop,J)'; 

time = 0.0; tStop = 1.0; dt = 0.025; 
alpha = 0.1; r = alpha*dt/(dx^2); S=1.0;

T = zeros(J,J,2);  

while (time < tStop)
    T(1,:,:) = 0; T(:,1,:) = 0; T(:,J,:) = 0;
    T(J,2:J-1,2) = (1-4*r)*T(J,2:J-1,1) + r*( 2*T(J-1,2:J-1,1) + T(J,3:J,1) + T(J,1:J-2) ) + S*dt;       
    for i = 2:J-1
        for j =  2:J-1
            T(i,j,2)=(1-4*r)*T(i,j,1) + r*( T(i+1,j,1) + T(i-1,j,1) + T(i,j+1,1) + T(i,j-1,1) ) + S*dt;
        end
    end
    time = time + dt;
    T(:,:,1) = T(:,:,2);       
end   
xlabel('y'); ylabel('x'); zlabel('T');
title '2-D heat equation with ADI method';

figure(1)
surf(y,x,T(:,:,1));
xlabel('y'), ylabel('x'), zlabel('T'), grid on
title '2-D heat equation with ADI method'
end