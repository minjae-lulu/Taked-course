%hw4_1_30


function y = hw4_1_30(x)

y = [x(4)*(-tan(x(2)) + tan(x(1))) - 16;
    x(4)*(tan(x(3)) + tan(x(2))) - 20;
    -4*sin(x(1)) - 6*sin(x(2)) + 5*sin(x(3)) + 3;
    4*cos(x(1)) + 6*cos(x(2)) + 5*cos(x(3)) - 12];
