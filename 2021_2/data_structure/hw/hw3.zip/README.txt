This directory contains checking programs for assignment 3.

INSTRUCTIONS

1. First copy your tree.h file into this directory.

2. Type "make"

3. Type "./test1". Checking basic functionality of the Tree class.

4. Type "./test2". Checks I/O functions. The log is written in "log2.txt".

5. Type "./test3". This program checks correctness of your solution to vertex cover for 8 instance files.

6. Type "./test4". This program checks whether your destructor causes memory leaks.

